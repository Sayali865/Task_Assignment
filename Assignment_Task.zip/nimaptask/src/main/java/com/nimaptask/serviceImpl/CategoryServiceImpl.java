package com.nimaptask.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.nimaptask.entity.Category;
import com.nimaptask.exception.CategoryIdNotFoundException;
import com.nimaptask.repository.CategoryRepository;
import com.nimaptask.repository.ProductRepository;
import com.nimaptask.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	private static final int PAGE_SIZE = 10;
	private final CategoryRepository cRepo;
	
	 @Autowired
	    public CategoryServiceImpl(CategoryRepository cRepo) {
	        this.cRepo = cRepo;
	    }

	@Override
	public Category addCategory(Category category) {
		
		return cRepo.save(category);
	}

	@Override
	public Category updateCategoryDetail(Category category, int categoryId) {
		Category updatecategory = cRepo.findById(categoryId)
				.orElseThrow(() -> new CategoryIdNotFoundException("category not found")); 
		
		updatecategory.setCategoryId(category.getCategoryId());
		updatecategory.setCategoryName(category.getCategoryName());
		return cRepo.save(updatecategory);
	}

	@Override
	public Category getCategory(int CategoryId) {
		return cRepo.findById(CategoryId).orElseThrow(() -> new CategoryIdNotFoundException("category not found"));
	}

	@Override
	public void deleteCategory(int CategoryId) {
		Category deleteCategory = cRepo.findById(CategoryId)
			.orElseThrow(() ->new CategoryIdNotFoundException("Category Deleted"));
		
	}


	@Override
    public Page<Category> getPageCategories(int page) {
    	
	      return cRepo.findAll(PageRequest.of(page, PAGE_SIZE));
	}

}
