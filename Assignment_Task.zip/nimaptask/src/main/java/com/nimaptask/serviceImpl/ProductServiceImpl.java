package com.nimaptask.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

//import com.nimaptask.dto.Productdto;
import com.nimaptask.entity.Product;
import com.nimaptask.exception.ProductIdNotFoundException;
import com.nimaptask.exception.ResourceNotFoundException;
import com.nimaptask.repository.ProductRepository;
import com.nimaptask.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	private static final int PAGE_SIZE = 10;
	private final ProductRepository productRepo;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepo) {
        this.productRepo = productRepo;
    }

	
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepo.save(product);
	}

	@Override
    public Product updateProductDetail(Product product, int productId) {
        Product updateProduct = productRepo.findById(productId)
                .orElseThrow(() -> new ProductIdNotFoundException("Product id is not correct"));

       
        updateProduct.setProductId(product.getProductId());
        updateProduct.setDescription(product.getDescription());
        updateProduct.setName(product.getName());
        updateProduct.setPrice(product.getPrice());

        return productRepo.save(updateProduct);
    }

	@Override
	public Product getProduct(int productId) {
		 return productRepo.findById(productId)
	                .orElseThrow(() -> new ProductIdNotFoundException("Product id is not correct"));
	}

	@Override
	public void deleteProduct(int productId) {
		
		Product deleteProduct=productRepo.findById(productId).orElseThrow(()->new ProductIdNotFoundException("product id is not correct"));
	    productRepo.delete(deleteProduct);
	    
		
	}



	@Override
    public Page<Product> getPageProducts(int page) {
		
        return productRepo.findAll(PageRequest.of(page, PAGE_SIZE));
    }




}
