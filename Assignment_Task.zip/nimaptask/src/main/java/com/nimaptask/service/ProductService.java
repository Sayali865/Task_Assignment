package com.nimaptask.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.nimaptask.entity.Product;



public interface ProductService {

	   Product addProduct(Product product);
	
	   Product updateProductDetail(Product product, int productId);
	   
	   Product getProduct(int productId);
	   
	   void deleteProduct(int productId);
	   
	   //List<Product> getAllProducts(); 
	   
	  
	   Page<Product> getPageProducts(int page);
}
