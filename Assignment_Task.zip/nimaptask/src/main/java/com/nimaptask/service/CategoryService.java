package com.nimaptask.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.nimaptask.entity.Category;


public interface CategoryService {

	 Category addCategory(Category  category);
		
	 Category updateCategoryDetail(Category category, int categoryId);
	   
	 Category getCategory(int CategoryId);
	   
	 void deleteCategory(int CategoryId);
	   
	   //List<Category> getAllCategory(); 
	   
	   Page<Category> getPageCategories(int page);
}
