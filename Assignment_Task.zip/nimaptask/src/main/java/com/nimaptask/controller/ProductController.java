package com.nimaptask.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.nimaptask.dto.Productdto;
import com.nimaptask.entity.Product;
import com.nimaptask.service.ProductService;

import jakarta.validation.Valid;


	@RestController
	@RequestMapping("/api/products")
	public class ProductController {
		
		@Autowired
		ProductService pservice;
		
		@PostMapping("/")
		public ResponseEntity<Product> saveProduct(@Valid @RequestBody Product product)
		{
			return new ResponseEntity<Product>(pservice.addProduct(product),HttpStatus.CREATED);
			
		}
		
		@GetMapping("/{productId}")
		public ResponseEntity<Product> getProduct(@PathVariable("productId") int productId)
		{
			return new ResponseEntity<Product>(pservice.getProduct(productId),HttpStatus.OK);		
			
		}
		
		@PutMapping("/{productId}")
		public ResponseEntity<Product>editProduct(@Valid @PathVariable("productId") int productId, @RequestBody Product product)
		{
			return new ResponseEntity<Product>(pservice.updateProductDetail(product, productId) , HttpStatus.OK);
		}
		
		@DeleteMapping("/{productId}")
		public ResponseEntity<String> deleteProduct(@PathVariable("productId") int productId)
		{
			pservice.deleteProduct(productId);
			return new ResponseEntity<String>("Deleted",HttpStatus.OK);	
			
		}
		
		    @GetMapping
		    public Page<Product> getPageProducts(@RequestParam(defaultValue = "0") int page) {
		        return pservice.getPageProducts(page);
		    }
		    

}
