package com.nimaptask.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nimaptask.entity.Category;
import com.nimaptask.entity.Product;
import com.nimaptask.service.CategoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/category")
public class CategoryController {
	
	@Autowired
	CategoryService cservice;
	
	@PostMapping("/create")
	public ResponseEntity<Category> saveCategory(@Valid @RequestBody Category category)
	{
		return new ResponseEntity<Category>(cservice.addCategory(category),HttpStatus.CREATED);		
	}
	
	@GetMapping("/{categoryId}")
	public ResponseEntity<Category> getCategory(@PathVariable("categoryId") int categoryId)
	{
		return new ResponseEntity<Category>(cservice.getCategory(categoryId),HttpStatus.OK);		
	}
	
	@PutMapping("/{categoryId}")
	public ResponseEntity<Category>editCategory(@Valid @PathVariable("categoryId") int categoryId, @RequestBody Category category)
	{
		return new ResponseEntity<Category>(cservice.updateCategoryDetail(category, categoryId) , HttpStatus.OK);
	}
	
	@DeleteMapping("{categoryId}")
	public ResponseEntity<String> deleteCategory(@PathVariable("categoryId") int categoryId)
	{
		cservice.deleteCategory(categoryId);
		return new ResponseEntity<String>("Deleted",HttpStatus.OK);	
		
	}

	    @GetMapping
	    public Page<Category> getPageCategories(@RequestParam(defaultValue = "0") int page) {
			
	        return cservice.getPageCategories(page);
	    }
}
